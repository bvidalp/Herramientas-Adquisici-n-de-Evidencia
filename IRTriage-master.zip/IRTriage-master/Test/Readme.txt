Test scripts for additional features
