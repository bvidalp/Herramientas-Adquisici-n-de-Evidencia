http://www.nirsoft.net/utils/csvfileview.zip
http://www.nirsoft.net/utils/winprefetchview.zip
