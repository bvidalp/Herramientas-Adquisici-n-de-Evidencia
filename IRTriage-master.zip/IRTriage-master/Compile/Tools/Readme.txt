https://github.com/AJMartel/IRTriageCMD/blob/master/cmd.exe?raw=true
   Save to Compile\Tools\cmd.exe

http://www.7-zip.org/a/7z1514-extra.7z
   Extract 7za.exe to Compile\Tools\7za.exe 
   Extract x64\7za.exe to Compile\Tools\7za64.exe
   
http://www.ltr-data.se/files/dosdev.zip
   Extract dosdev.exe to Compile\Tools\dosdev.exe
   
https://sourceforge.net/projects/md5deep/files/md5deep/md5deep-4.3/md5deep-4.3.zip/download
   Extract md5deep-4.3\md5deep.exe to Compile\Tools\md5deep.exe
   Extract md5deep-4.3\md5deep64.exe to Compile\Tools\md5deep64.exe
   Extract md5deep-4.3\sha1deep.exe to Compile\Tools\sha1deep.exe
   Extract md5deep-4.3\sha1deep64.exe to Compile\Tools\sha1deep64.exe
   
https://www.microsoft.com/en-us/download/confirmation.aspx?id=17657   
   Extract robocopy.exe to Compile\Tools\robocopy.exe
   Extract x64\robocopy.exe to Compile\Tools\robo7.exe?
  
